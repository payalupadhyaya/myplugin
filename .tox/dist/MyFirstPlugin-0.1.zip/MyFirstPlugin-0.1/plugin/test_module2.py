from __future__ import unicode_literals, absolute_import
from __future__ import print_function, division

def test_myplugin():
    print("Test myplugin")




