from __future__ import absolute_import
from __future__ import unicode_literals

__author__ = 'Hewlett Packard Enterprise Development LP'
__email__ = 'payal.upadhyaya@hpe.com'
__version__ = '0.1.0'

#from mypack.packmodule import module3
