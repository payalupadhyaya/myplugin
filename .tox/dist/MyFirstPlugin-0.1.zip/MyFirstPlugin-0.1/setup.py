from setuptools import setup, find_packages

setup(
    name='MyFirstPlugin',
    version='0.1',
#    packages=find_packages(),
    packages=['plugin',],
    license='Creative Commons Attribution-Noncommercial-Share Alike license',
    long_description=open('README.txt').read(),
    entry_points = {
        'pytest11': ['plugin=plugin.myentrypoint'],
    }
)


